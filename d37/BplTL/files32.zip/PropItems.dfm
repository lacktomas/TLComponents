inherited PropItemsForm: TPropItemsForm
  Caption = 'PropItemsForm'
  ClientWidth = 717
  Position = poDesigned
  StyleElements = [seFont, seClient, seBorder]
  ExplicitWidth = 733
  TextHeight = 13
  inherited ListView1: TLColorListView
    Width = 417
    Columns = <
      item
        Caption = 'Index'
        Width = 40
      end
      item
        Caption = 'Alias'
        Width = 60
      end
      item
        Caption = 'Component'
        Width = 140
      end
      item
        Caption = 'PropertyName'
        Width = 80
      end
      item
        Caption = 'Description'
        Width = 70
      end>
  end
  inherited ToolBar1: TToolBar
    Width = 717
  end
  inherited Panel1: TPanel
    Left = 417
    StyleElements = [seFont, seClient, seBorder]
    inherited Panel3: TPanel
      StyleElements = [seFont, seClient, seBorder]
    end
  end
  inherited Panel2: TPanel
    Width = 717
    StyleElements = [seFont, seClient, seBorder]
    inherited CloseBtn: TBitBtn
      Left = 627
    end
  end
end
