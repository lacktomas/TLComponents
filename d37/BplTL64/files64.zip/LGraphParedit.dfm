object GParEditDlg: TGParEditDlg
  Left = 305
  Top = 160
  Caption = 'Parameters editor'
  ClientHeight = 263
  ClientWidth = 489
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'System'
  Font.Style = []
  Position = poScreenCenter
  TextHeight = 16
  object OkBtn: TBitBtn
    Left = 404
    Top = 12
    Width = 77
    Height = 29
    Margins.Left = 2
    Margins.Top = 2
    Margins.Right = 2
    Margins.Bottom = 2
    Caption = 'Ok'
    Kind = bkOK
    NumGlyphs = 2
    TabOrder = 5
    OnClick = OkBtnClick
  end
  object CancelBtn: TBitBtn
    Left = 404
    Top = 44
    Width = 77
    Height = 29
    Margins.Left = 2
    Margins.Top = 2
    Margins.Right = 2
    Margins.Bottom = 2
    Kind = bkCancel
    NumGlyphs = 2
    TabOrder = 6
  end
  object GroupBox1: TGroupBox
    Left = 8
    Top = 4
    Width = 189
    Height = 81
    Margins.Left = 2
    Margins.Top = 2
    Margins.Right = 2
    Margins.Bottom = 2
    Caption = 'Range X'
    TabOrder = 0
    object Label1: TLabel
      Left = 8
      Top = 20
      Width = 64
      Height = 16
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      Caption = '&Minimum:'
      FocusControl = MinimumX
    end
    object Label2: TLabel
      Left = 8
      Top = 48
      Width = 68
      Height = 16
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      Caption = 'Ma&ximum:'
      FocusControl = MaximumX
    end
    object MinimumX: TEdit
      Left = 84
      Top = 16
      Width = 97
      Height = 24
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      TabOrder = 0
    end
    object MaximumX: TEdit
      Left = 84
      Top = 48
      Width = 97
      Height = 24
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      TabOrder = 1
    end
  end
  object GroupBox2: TGroupBox
    Left = 8
    Top = 88
    Width = 189
    Height = 99
    Margins.Left = 2
    Margins.Top = 2
    Margins.Right = 2
    Margins.Bottom = 2
    Caption = 'Steps X'
    TabOrder = 1
    object Label3: TLabel
      Left = 8
      Top = 24
      Width = 38
      Height = 16
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      Caption = '&Ticks:'
      FocusControl = TicksX
    end
    object Label5: TLabel
      Left = 8
      Top = 52
      Width = 48
      Height = 16
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      Caption = '&Labels:'
      FocusControl = LabelsX
    end
    object TicksX: TEdit
      Left = 84
      Top = 16
      Width = 97
      Height = 24
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      TabOrder = 0
    end
    object LabelsX: TEdit
      Left = 84
      Top = 48
      Width = 97
      Height = 24
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      TabOrder = 1
    end
    object Log10XChB: TCheckBox
      Left = 83
      Top = 79
      Width = 74
      Height = 17
      Caption = 'Log10'
      TabOrder = 2
    end
  end
  object GroupBox3: TGroupBox
    Left = 7
    Top = 202
    Width = 389
    Height = 49
    Margins.Left = 2
    Margins.Top = 2
    Margins.Right = 2
    Margins.Bottom = 2
    Caption = 'Warnings'
    TabOrder = 4
    object Label6: TLabel
      Left = 8
      Top = 24
      Width = 30
      Height = 16
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      Caption = 'Lo&w:'
      FocusControl = Low
    end
    object Label7: TLabel
      Left = 208
      Top = 20
      Width = 34
      Height = 16
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      Caption = '&High:'
      FocusControl = High
    end
    object Low: TEdit
      Left = 84
      Top = 16
      Width = 97
      Height = 24
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      TabOrder = 0
    end
    object High: TEdit
      Left = 284
      Top = 16
      Width = 97
      Height = 24
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      TabOrder = 1
    end
  end
  object GroupBox4: TGroupBox
    Left = 208
    Top = 4
    Width = 189
    Height = 81
    Margins.Left = 2
    Margins.Top = 2
    Margins.Right = 2
    Margins.Bottom = 2
    Caption = 'Range Y'
    TabOrder = 2
    object Label4: TLabel
      Left = 8
      Top = 20
      Width = 64
      Height = 16
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      Caption = '&Minimum:'
      FocusControl = MinimumX
    end
    object Label8: TLabel
      Left = 8
      Top = 48
      Width = 68
      Height = 16
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      Caption = 'Ma&ximum:'
      FocusControl = MaximumX
    end
    object MinimumY: TEdit
      Left = 84
      Top = 16
      Width = 97
      Height = 24
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      TabOrder = 0
    end
    object MaximumY: TEdit
      Left = 84
      Top = 48
      Width = 97
      Height = 24
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      TabOrder = 1
    end
  end
  object GroupBox5: TGroupBox
    Left = 208
    Top = 88
    Width = 189
    Height = 99
    Margins.Left = 2
    Margins.Top = 2
    Margins.Right = 2
    Margins.Bottom = 2
    Caption = 'Steps Y'
    TabOrder = 3
    object Label9: TLabel
      Left = 8
      Top = 24
      Width = 38
      Height = 16
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      Caption = '&Ticks:'
      FocusControl = TicksX
    end
    object Label10: TLabel
      Left = 8
      Top = 52
      Width = 48
      Height = 16
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      Caption = '&Labels:'
      FocusControl = LabelsX
    end
    object TicksY: TEdit
      Left = 84
      Top = 16
      Width = 97
      Height = 24
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      TabOrder = 0
    end
    object LabelsY: TEdit
      Left = 84
      Top = 48
      Width = 97
      Height = 24
      Margins.Left = 2
      Margins.Top = 2
      Margins.Right = 2
      Margins.Bottom = 2
      TabOrder = 1
    end
    object Log10YChB: TCheckBox
      Left = 83
      Top = 79
      Width = 74
      Height = 17
      Caption = 'Log10'
      TabOrder = 2
    end
  end
end
