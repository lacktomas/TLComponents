object GParEditLGDlg: TGParEditLGDlg
  Left = 305
  Top = 160
  Caption = 'Parameters editor'
  ClientHeight = 232
  ClientWidth = 493
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'System'
  Font.Style = []
  Position = poScreenCenter
  TextHeight = 16
  object OkBtn: TBitBtn
    Left = 404
    Top = 12
    Width = 85
    Height = 29
    Caption = 'Ok'
    Kind = bkOK
    NumGlyphs = 2
    TabOrder = 5
    OnClick = OkBtnClick
  end
  object CancelBtn: TBitBtn
    Left = 404
    Top = 44
    Width = 85
    Height = 29
    Kind = bkCancel
    NumGlyphs = 2
    TabOrder = 6
  end
  object GroupBox1: TGroupBox
    Left = 8
    Top = 4
    Width = 189
    Height = 81
    Caption = 'Range X'
    TabOrder = 0
    object Label1: TLabel
      Left = 8
      Top = 20
      Width = 64
      Height = 16
      Caption = '&Minimum:'
      FocusControl = MinimumX
    end
    object Label2: TLabel
      Left = 8
      Top = 48
      Width = 68
      Height = 16
      Caption = 'Ma&ximum:'
      FocusControl = MaximumX
    end
    object MinimumX: TEdit
      Left = 84
      Top = 16
      Width = 97
      Height = 24
      TabOrder = 0
    end
    object MaximumX: TEdit
      Left = 84
      Top = 48
      Width = 97
      Height = 24
      TabOrder = 1
    end
  end
  object GroupBox2: TGroupBox
    Left = 8
    Top = 88
    Width = 189
    Height = 81
    Caption = 'Steps X'
    TabOrder = 1
    object Label3: TLabel
      Left = 8
      Top = 24
      Width = 38
      Height = 16
      Caption = '&Ticks:'
      FocusControl = TicksX
    end
    object Label5: TLabel
      Left = 8
      Top = 52
      Width = 48
      Height = 16
      Caption = '&Labels:'
      FocusControl = LabelsX
    end
    object TicksX: TEdit
      Left = 84
      Top = 16
      Width = 97
      Height = 24
      TabOrder = 0
    end
    object LabelsX: TEdit
      Left = 84
      Top = 48
      Width = 97
      Height = 24
      TabOrder = 1
    end
  end
  object GroupBox3: TGroupBox
    Left = 8
    Top = 172
    Width = 389
    Height = 49
    Caption = 'Warnings'
    TabOrder = 4
    object Label6: TLabel
      Left = 8
      Top = 24
      Width = 30
      Height = 16
      Caption = 'Lo&w:'
      FocusControl = Low
    end
    object Label7: TLabel
      Left = 208
      Top = 20
      Width = 34
      Height = 16
      Caption = '&High:'
      FocusControl = High
    end
    object Low: TEdit
      Left = 84
      Top = 16
      Width = 97
      Height = 24
      TabOrder = 0
    end
    object High: TEdit
      Left = 284
      Top = 16
      Width = 97
      Height = 24
      TabOrder = 1
    end
  end
  object GroupBox4: TGroupBox
    Left = 208
    Top = 4
    Width = 189
    Height = 81
    Caption = 'Range Y'
    TabOrder = 2
    object Label4: TLabel
      Left = 8
      Top = 20
      Width = 64
      Height = 16
      Caption = '&Minimum:'
      FocusControl = MinimumX
    end
    object Label8: TLabel
      Left = 8
      Top = 48
      Width = 68
      Height = 16
      Caption = 'Ma&ximum:'
      FocusControl = MaximumX
    end
    object MinimumY: TEdit
      Left = 84
      Top = 16
      Width = 97
      Height = 24
      TabOrder = 0
    end
    object MaximumY: TEdit
      Left = 84
      Top = 48
      Width = 97
      Height = 24
      TabOrder = 1
    end
  end
  object GroupBox5: TGroupBox
    Left = 208
    Top = 88
    Width = 189
    Height = 81
    Caption = 'Steps Y'
    TabOrder = 3
    object Label9: TLabel
      Left = 8
      Top = 24
      Width = 38
      Height = 16
      Caption = '&Ticks:'
      FocusControl = TicksX
    end
    object Label10: TLabel
      Left = 8
      Top = 52
      Width = 48
      Height = 16
      Caption = '&Labels:'
      FocusControl = LabelsX
    end
    object TicksY: TEdit
      Left = 84
      Top = 16
      Width = 97
      Height = 24
      TabOrder = 0
    end
    object LabelsY: TEdit
      Left = 84
      Top = 48
      Width = 97
      Height = 24
      TabOrder = 1
    end
  end
end
