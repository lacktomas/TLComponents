inherited VarListForm: TVarListForm
  Caption = 'VarListForm'
  ClientWidth = 1066
  Constraints.MinHeight = 246
  Constraints.MinWidth = 369
  ExplicitWidth = 1082
  TextHeight = 13
  inherited ListView1: TLColorListView
    Width = 766
    Columns = <
      item
        Caption = 'Nr.'
        Width = 40
      end
      item
        Caption = 'Variable'
        Width = 150
      end
      item
        Caption = 'Unit'
      end
      item
        Caption = 'Filtered'
      end
      item
        Caption = 'Scale'
      end
      item
        Caption = 'Offset'
      end
      item
        Caption = 'Prl. Min'
      end
      item
        Caption = 'Prl. Max'
      end
      item
        Caption = 'Prl. V0'
      end
      item
        Caption = 'Description'
        Width = 138
      end
      item
        Caption = 'Color'
        Width = 57
      end>
    OnAdvancedCustomDrawItem = ListView1AdvancedCustomDrawItem
    OnAdvancedCustomDrawSubItem = ListView1AdvancedCustomDrawSubItem
    ExplicitWidth = 766
  end
  inherited ToolBar1: TToolBar
    Width = 1066
    ExplicitWidth = 1066
  end
  inherited Panel1: TPanel
    Left = 766
    ExplicitLeft = 766
    inherited Splitter1: TSplitter
      Top = 230
      Height = 4
      Constraints.MaxHeight = 4
      Constraints.MinHeight = 4
      ExplicitTop = 225
      ExplicitHeight = 4
    end
    inherited InfoBox: TPaintBox
      Constraints.MinHeight = 29
      ExplicitTop = 232
    end
    inherited Panel3: TPanel
      Height = 230
      Constraints.MinHeight = 29
      ExplicitHeight = 230
    end
  end
  inherited Panel2: TPanel
    Width = 1066
    ExplicitWidth = 1066
    DesignSize = (
      1066
      40)
    inherited CloseBtn: TBitBtn
      Left = 974
      Top = 8
      ExplicitLeft = 974
      ExplicitTop = 8
    end
  end
end
