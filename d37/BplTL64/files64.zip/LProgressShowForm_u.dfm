object LProgressShowForm: TLProgressShowForm
  Left = 0
  Top = 0
  BorderIcons = []
  BorderStyle = bsSingle
  Caption = 'Progress'
  ClientHeight = 69
  ClientWidth = 438
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  FormStyle = fsStayOnTop
  Position = poScreenCenter
  TextHeight = 15
  object ProgressBar1: TProgressBar
    Left = 8
    Top = 24
    Width = 425
    Height = 25
    Step = 1
    TabOrder = 0
  end
end
