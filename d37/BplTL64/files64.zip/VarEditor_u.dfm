inherited VarEditorForm: TVarEditorForm
  Left = 313
  Top = 254
  Caption = 'VarEditorForm'
  ClientHeight = 298
  ClientWidth = 790
  Font.Height = -9
  StyleElements = [seFont, seClient, seBorder]
  ExplicitWidth = 806
  ExplicitHeight = 337
  TextHeight = 13
  inherited ListView1: TListView
    Top = 46
    Width = 790
    Height = 252
    Columns = <
      item
        Caption = 'Index'
        Width = 39
      end
      item
        Caption = 'Name'
        Width = 120
      end
      item
        Caption = 'Typ'
        Width = 120
      end
      item
        Caption = 'Filter'
        Width = 144
      end
      item
        Caption = 'Equation'
        Width = 150
      end
      item
        Caption = 'Description'
        Width = 187
      end>
    SmallImages = DataModule1.ImageList9
    ExplicitTop = 46
    ExplicitWidth = 790
    ExplicitHeight = 252
  end
  inherited ToolBar1: TToolBar
    Width = 790
    Height = 46
    ButtonHeight = 44
    ButtonWidth = 44
    ExplicitWidth = 790
    ExplicitHeight = 46
    inherited AddBtn: TToolButton
      DropdownMenu = PopupMenu1
      Style = tbsDropDown
      ExplicitWidth = 59
      ExplicitHeight = 44
    end
    inherited DeleteBtn: TToolButton
      Left = 59
      ExplicitLeft = 59
      ExplicitWidth = 44
      ExplicitHeight = 44
    end
    inherited ToolButton3: TToolButton
      Left = 103
      ExplicitLeft = 103
      ExplicitHeight = 44
    end
    inherited MoveUpBtn: TToolButton
      Left = 110
      ExplicitLeft = 110
      ExplicitWidth = 44
      ExplicitHeight = 44
    end
    inherited MoveDownBtn: TToolButton
      Left = 154
      ExplicitLeft = 154
      ExplicitWidth = 44
      ExplicitHeight = 44
    end
    inherited ToolButton1: TToolButton
      Left = 198
      ExplicitLeft = 198
      ExplicitHeight = 44
    end
    inherited SetupBtn: TToolButton
      Left = 204
      ExplicitLeft = 204
      ExplicitWidth = 44
      ExplicitHeight = 44
    end
  end
  object PopupMenu1: TPopupMenu
    Images = DataModule1.ImageList8
    Left = 18
    Top = 76
    object Boolean1: TMenuItem
      Caption = '&Boolean'
      ImageIndex = 0
      Visible = False
      OnClick = Boolean1Click
    end
    object Integer1: TMenuItem
      Caption = '&Integer'
      ImageIndex = 1
      Visible = False
      OnClick = Integer1Click
    end
    object Float1: TMenuItem
      Caption = '&Float'
      ImageIndex = 2
      OnClick = Float1Click
    end
    object String1: TMenuItem
      Caption = '&String'
      ImageIndex = 3
      Visible = False
      OnClick = String1Click
    end
    object Variant1: TMenuItem
      Caption = '&Variant'
      ImageIndex = 4
      Visible = False
      OnClick = Variant1Click
    end
    object N1: TMenuItem
      Caption = '-'
    end
    object TimeStampVector1: TMenuItem
      Caption = 'TimeStamp Vector'
      ImageIndex = 5
      Visible = False
      OnClick = TimeStampVector1Click
    end
    object BooleanVector1: TMenuItem
      Caption = 'Boolean Vector'
      ImageIndex = 6
      Visible = False
      OnClick = BooleanVector1Click
    end
    object SmallIntVector1: TMenuItem
      Caption = 'SmallInt Vector'
      ImageIndex = 7
      Visible = False
      OnClick = SmallIntVector1Click
    end
    object IntegerVector1: TMenuItem
      Caption = 'Integer Vector'
      ImageIndex = 7
      Visible = False
      OnClick = IntegerVector1Click
    end
    object DoubleVector1: TMenuItem
      Caption = 'Double Vector'
      ImageIndex = 8
      OnClick = DoubleVector1Click
    end
    object FloatVector1: TMenuItem
      Caption = 'Float Vector'
      ImageIndex = 9
      OnClick = FloatVector1Click
    end
    object StringVector1: TMenuItem
      Caption = 'String Vector'
      ImageIndex = 10
      Visible = False
      OnClick = StringVector1Click
    end
    object VariantVector1: TMenuItem
      Caption = 'Variant Vector'
      ImageIndex = 11
      Visible = False
      OnClick = VariantVector1Click
    end
    object N2: TMenuItem
      Caption = '-'
    end
    object FloatMatrix1: TMenuItem
      Caption = 'Float Matrix'
      ImageIndex = 12
      OnClick = FloatMatrix1Click
    end
    object VariantMatrix1: TMenuItem
      Caption = 'Variant Matrix'
      ImageIndex = 13
      Visible = False
      OnClick = VariantMatrix1Click
    end
  end
end
